# Discord-Bot-dyno
this bot has every feature that dyno has plus a bit of dank memers it also has a working whitelist and blacklist system enjoy contact me for more details or if you need help my discord is Airpods#6969 
